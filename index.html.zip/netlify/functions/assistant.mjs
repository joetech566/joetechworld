const SATELLITE_KNOWLEDGE = `
JOETECHWORLD REFERENCE NOTES
IMPORTANT: These are user-supplied reference notes, not a guarantee that every frequency/channel is current or available in every country. Tell users to verify current parameters for their location and service.

MASTER DECODER TYPE 2 (as supplied):
- Press MENU on remote.
- Go to ANTENNA SETTINGS and press OK.
- Choose satellite: Astra 4A / Astra 2E/2F / Hotbird, as appropriate to the user's target.
- LNB Power: ON.
- LNB Frequency: 9750/10600.
- DiSEqC 1.0: None or OFF if no DiSEqC switch is used; otherwise choose the correct port.
- DiSEqC 1.1: None or OFF if not used.
- Exit; go to TP List.
- Add a transponder using the colour button shown on the decoder screen.
- Example reference transponder: 12522 or 12525 MHz, symbol rate 30000, polarity V (Vertical).
- Track SIGNAL QUALITY while aligning dish.
- Exit; open SATELLITE LIST; press OK.
- Press BLUE to scan; MODE: BLIND; TV/RADIO: ALL; press OK.
- After scanning, press OK to save and EXIT three times.

NEWMAX COMBO (as supplied):
- MENU > ANTENNA SETTINGS > OK.
- Choose the satellite selected in antenna settings (reference says Astra 4A / Hotbird).
- LNB Type: Ku Band; LNB Frequency: 9750/10600.
- DiSEqC 1.0 and 1.1: None/OFF if no switch is used; otherwise select the correct switch port.
- EXIT; go to TP LIST; press OK.
- Press SAT button to select the satellite set in antenna settings.
- Add transponder: 12522 or 12525 MHz, symbol rate 30000, polarity V (Vertical).
- Press OK twice to add and mark the transponder.
- Track SIGNAL QUALITY.
- Press BLUE to scan; Network Search: ON; press OK.
- After scanning, press OK to save and EXIT three times.

TRANSPONDER REFERENCE supplied in the user's image (MHz; polarity H=Horizontal, V=Vertical; symbol rates are as listed):
- MULTI TV / ANGLE 28.2E: 12522 V 30000; 12525 V 30000; 11595 V 30000; 11095 V 30000; 11675 H 30000; 11635 V 30000; 12605 V 30000; 11675 V 30000; 12725 V 30000 (digital channels, note in source: GTV, GTV Sports Plus, etc.).
- ABS 3 / ANGLE 3.0W: 11171 V 30000; 11008 H 30000; 11091 V 30000; 10975 H 30000.
- DSTV / ANGLE 36.0E / EUTELSAT W4 or W7: 12245 H 27500; 11900 H 27500; 11747 H 27500; 11842 V 27500; 11728 V 27500; 12284 H 27500.
- MBC WEST / NILESAT / ANGLE 7.0W: 11560 H 27500; 11685 H 27500; 11475 H 27500; 11559 H 27500.
- STARTIMES / SES 5 / ANGLE 78.5 to 81E: 11976 V 27500; 11861 V 27500; 12341 H 27500; 12379 H 27500.
- MALI / EUTELSAT 37A / ANGLE 37W: 12341 V 02120; 12345 V 02120 (transcribed as shown; verify before use).
- CANAL+ / ANGLE 22.0W / SES 7: 10986 V 30000; 12565 V 30000; 12603 V 30000; 12722 V 30000.
- MY TV / POSITION WEST: 10986 V 26657.
- SERIOUS VOX AFRICA / 4.9E: 12054 V 29950; 12015 V 29950; 12035 V 29950; 11919 H 27500; 11939 V 27500; 11881 H 27500; 12341 H 27500.
- SANTATA (FRENCH CHANNELS) / ANGLE 16.0E: 10804 H 30000; 12521 H 30000; 12563 H 30000; 12604 H 30000; 11356 H 30000.
- JW: 12601 H 30000; 12604 H 30000.
- TSTV / YAMAL 402 / ANGLE 42E: 1110 H 30000 (as transcribed; verify frequency format).
- ISLAMIC: 12601 H 30000; 12604 H 30000.
- NIGCOMSAT / 42.0E: 12518 H 29500.

GENERAL TROUBLESHOOTING:
- No signal: check dish line of sight, secure mounting, correct satellite/orbital position for location, cable/connectors, LNB power, LNB type, DiSEqC port, and whether the transponder is current.
- Signal strength but no quality: fine-tune azimuth/elevation/skew; confirm correct satellite and active transponder; check LNB skew and cable connectors.
- No channels after scan: verify satellite/transponder, scan mode, network search option, and save/exit steps.
- LNB frequency 9750/10600 is a common universal Ku-band LNB setting; use the actual LNB specification if different.
- DiSEqC must not be set to OFF when a switch is installed and used.
- Installation at height requires safe access and appropriate fall protection.
`;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};

function json(statusCode, payload) {
  return { statusCode, headers: corsHeaders, body: JSON.stringify(payload) };
}

export async function handler(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: corsHeaders, body: "" };
  if (event.httpMethod !== "POST") return json(405, { error: "Use POST to ask the JOETECHWORLD assistant." });

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "Please send a valid question." }); }

  const question = String(body.question || "").trim();
  if (!question) return json(400, { error: "Please type a satellite installation question." });
  if (question.length > 4000) return json(400, { error: "Please keep your question under 4,000 characters." });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(200, { answer: localAnswer(question) + "\n\nNote: The live AI connection is not configured yet. Add OPENAI_API_KEY in Netlify → Site configuration → Environment variables, then redeploy to enable AI-powered answers." });
  }

  try {
    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: `You are JOETECHWORLD's helpful satellite installation assistant. Give practical, clear numbered steps. Ask for the decoder model, satellite, and country/location if needed. Never claim a listed frequency is guaranteed current. Explain that the provided transponder table is user-supplied and should be verified. Correct unsafe assumptions, and never advise climbing or roof work without appropriate safety measures. Use these reference notes:\n${SATELLITE_KNOWLEDGE}`,
        input: question,
        max_output_tokens: 700
      })
    });
    const data = await apiResponse.json();
    if (!apiResponse.ok) {
      return json(502, { answer: localAnswer(question), error: "The live AI service returned an error. The built-in guide is still available.", detail: data?.error?.message || "AI request failed." });
    }
    const answer = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n").trim();
    return json(200, { answer: answer || localAnswer(question) });
  } catch {
    return json(502, { answer: localAnswer(question), error: "The live AI service could not be reached. Showing built-in guidance instead." });
  }
}

function localAnswer(question) {
  const q = question.toLowerCase();
  if (q.includes("newmax") || q.includes("new max")) {
    return "NEWMAX COMBO quick setup:\n1. Press MENU → ANTENNA SETTINGS → OK.\n2. Select the satellite you actually want to receive.\n3. Set LNB Type to Ku Band and LNB Frequency to 9750/10600 for a universal Ku LNB.\n4. Set DiSEqC 1.0/1.1 to OFF only if no switch is installed; otherwise select the correct port.\n5. EXIT → TP LIST. Select the same satellite using SAT.\n6. Add a valid transponder. Your supplied guide lists 12522 or 12525 MHz, symbol rate 30000, Vertical (V); verify that it is current for your target satellite.\n7. Watch SIGNAL QUALITY while carefully fine-tuning the dish.\n8. Press BLUE to scan, set Network Search ON, press OK, then OK to save and EXIT three times.";
  }
  if (q.includes("master decoder") || q.includes("decoder type 2") || q.includes("type 2")) {
    return "MASTER DECODER TYPE 2 quick setup:\n1. Press MENU → ANTENNA SETTINGS → OK.\n2. Select the correct target satellite.\n3. Set LNB Power ON and LNB Frequency 9750/10600 for a universal Ku-band LNB.\n4. Set DiSEqC 1.0/1.1 to None/OFF only if no switch is used; otherwise choose the correct port.\n5. EXIT → TP LIST and add a valid transponder. Your guide lists 12522 or 12525 MHz, symbol rate 30000, Vertical (V); confirm it is current for the satellite and your location.\n6. Track SIGNAL QUALITY while aligning the dish.\n7. EXIT → SATELLITE LIST → OK; press BLUE to scan, choose BLIND scan and TV/RADIO ALL, then press OK.\n8. Press OK to save and EXIT three times.";
  }
  if (q.includes("transponder") || q.includes("frequency") || q.includes("symbol rate") || q.includes("polarity")) {
    return "Your JOETECHWORLD guide includes a transponder reference for Multi TV (28.2°E), ABS 3 (3.0°W), DStv/Eutelsat (36.0°E), MBC West/Nilesat (7.0°W), StarTimes/SES 5, Canal+, Serious Vox Africa, Santata, NigComSat and others. Example listed values for Multi TV include 12522 V 30000 and 12525 V 30000. H means Horizontal; V means Vertical. Frequencies and channel availability can change, so verify the current transponder for your exact satellite and location before scanning.";
  }
  if (q.includes("no signal") || q.includes("signal quality") || q.includes("signal")) {
    return "For poor or missing signal quality:\n1. Confirm the dish has a clear line of sight and is aimed at the correct satellite for your location.\n2. Check coax cable, F-connectors, and LNB connection.\n3. Confirm LNB Power is ON and LNB frequency matches the installed LNB (9750/10600 is common for universal Ku-band LNBs).\n4. Check DiSEqC port if using a switch.\n5. Select a currently active transponder for the target satellite.\n6. Adjust dish azimuth/elevation and LNB skew in small movements while watching SIGNAL QUALITY, not only signal strength.\n7. Keep roof and ladder work safe; use appropriate fall protection.";
  }
  if (q.includes("scan") || q.includes("channels") || q.includes("channel")) {
    return "Before scanning, confirm the correct satellite, LNB setting, DiSEqC port, and a valid transponder with signal quality. For Master Decoder Type 2, your notes say BLUE → MODE BLIND → TV/RADIO ALL → OK, then OK to save and EXIT three times. For Newmax Combo, your notes say BLUE → Network Search ON → OK, then save and EXIT three times. Menu labels may vary by firmware.";
  }
  return "I can help with decoder setup, dish alignment, LNB settings, transponder entry, signal quality, and channel scanning. Please tell me your decoder model (for example, Master Decoder Type 2 or Newmax Combo), the satellite you want, and your country/city so I can guide you more accurately. The website's PDF installation guide is also available from the home page.";
}
