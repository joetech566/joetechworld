JOETECHWORLD RECOVERY PACKAGE
==============================

This package rebuilds a simple JOETECHWORLD website and includes:
- A responsive homepage
- A combined satellite installation PDF in /public
- An AI assistant endpoint in /netlify/functions/assistant.mjs
- Built-in offline guidance for Master Decoder Type 2, Newmax Combo, and the transponder notes
- WhatsApp contact button

IMPORTANT:
- This is a recovery/rebuild package; it does not restore your previous Netlify account or domain automatically.
- The live AI requires an OpenAI API key stored securely in Netlify. Never paste the key into index.html or publish it in a public repository.
- The built-in assistant still provides basic guide answers when the API key is not configured.
- Transponder information came from the supplied images and may be outdated or have transcription errors. Verify current frequencies before use.

EASIEST DEPLOYMENT (Netlify):
1. Extract this ZIP to a folder on your computer.
2. Sign in to Netlify and open your team/dashboard.
3. Create a new site by importing a Git repository, or use the Netlify CLI to deploy the whole project including functions.
4. If using GitHub: create a new repository, upload all files/folders from this extracted project, then in Netlify choose Add new site > Import an existing project and select that repository.
5. Netlify build settings:
   - Build command: leave blank
   - Publish directory: public
   - Functions directory: netlify/functions
   The project includes netlify.toml with these settings.
6. In Netlify site settings, add environment variable OPENAI_API_KEY with your own API key. Optional: OPENAI_MODEL (default gpt-4.1-mini).
7. Redeploy the site after setting the environment variable.
8. Test the home page, PDF link, WhatsApp button, and AI assistant.

If your old website name/domain still exists in Netlify, choose that existing site and deploy this project to it rather than creating a duplicate. If the old Netlify site was deleted, create a new site and reconnect your custom domain if you still own it.
